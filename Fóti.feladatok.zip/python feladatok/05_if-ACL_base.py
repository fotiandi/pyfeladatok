'''
The standard ACL numbers are between 1 and 99 (inclusive)
The extended ACL numbers are between 100 199 (inclusive)
Other ACL numbers are nor standard nor extended.
Input an ACL number and categorize it!
'''
print("4.feladat")

szam1 = input("Kérek egy számot 1 és 99 között: ")
szam2 = input("Kérek egy számot 100 és 199 között: ")
if szam1 > szam2:
    print("kisebb számot adj meg!")
elif szam1 < szam2:
    print("Jó számot adtál meg.")

if szam2 < szam1:
    print("kisebb számot adj meg!")



