# Create a list of the BRICS countries :Brazil, Russia, India, China, South Africa
"""Create a dictionary of BRICS capitals.
Note that South Africa has 3 capitals. Brasília, Moscow, New Delhi, (Pretoria, Cape Town, Bloemfontein)
"""
# Print the list and dictionary
"""
What response did you get?
Why did the list and dictionary contents not print?
Fix the code and run the script again.
"""
"""
Why did you get an error for the 2nd capital of South Africa?
Hint: Check the syntax for the index value.
"""
print("1.feladat")
Countries = ['Brazil', 'Russia', 'India', 'China', 'South Africa']
Capitals= ["Brasília", "Moscow", "New Delhi", "Pretoria"," Cape Town", "Bloemfontein"]
print("Countries:",", ".join(Countries))
print("capitals: ",", ".join(Capitals))

Capitals.remove("Brasília")
Capitals.remove("Moscow")
Capitals.remove("New Delhi")
print("The 3 South African capitals is: ",", ".join(Capitals))
