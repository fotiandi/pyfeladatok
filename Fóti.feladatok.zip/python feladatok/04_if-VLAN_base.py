# Create a simple IF function that compares nativeVLAN and dataVLAN values and prints result.

print("3.feladat")
nVLAN = input("Adj meg egy számot: ")
dVLAN = input("Adj meg egy számot: ")
if nVLAN > dVLAN:
  print(nVLAN," is greater than ", dVLAN)
elif nVLAN == dVLAN:
  print(nVLAN," and" ,dVLAN, "are equal")
else:
  print(dVLAN," is greater than ",nVLAN)