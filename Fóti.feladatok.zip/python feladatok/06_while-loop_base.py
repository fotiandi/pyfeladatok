'''
Write Python program :
    get an input for a number to count to
    if input is "q" or "quit", the program exits
    else write numbers from 1 to the number in one line, separated by space and goes back to the input
'''

print("5.feladat")
szam = int(input("Adjon meg egy számot: "))
if szam is quit:
    print("nem jó értéket adtál meg.")
else:
    print("jó értéket adtál meg.")

