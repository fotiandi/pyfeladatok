list = ['Brazil, Russia, India, China, South Africa']
dictionary = ['Brasilia, Moscow, New Delhi']
print( capitals["South Africa"[1]] )
